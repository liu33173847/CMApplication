﻿define([], function () {
    var signalRServiceConnnectorStub = {
        'load': function() {
            
        }, 
        'executeRequestedAction': function () {
        }
    };
    return signalRServiceConnnectorStub;
});