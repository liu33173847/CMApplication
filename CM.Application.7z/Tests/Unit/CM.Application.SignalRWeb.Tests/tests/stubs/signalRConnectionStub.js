﻿define([], function() {
    var signalRConnectionStub = {        
        connect: function() {
            
        },
        connectHub: function() {
            
        },
        start: function() {
            
        },
        executeRequestedAction: function() {

        }
    };
    return signalRConnectionStub;
});