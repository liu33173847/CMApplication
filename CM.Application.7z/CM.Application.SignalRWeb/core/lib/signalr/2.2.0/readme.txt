jquery.signalR-2.2.0.js was modified for ISR187389

The change was to improve reconnect timing so that it doesnt raise too early.
Compare the code with the previous version in GIT